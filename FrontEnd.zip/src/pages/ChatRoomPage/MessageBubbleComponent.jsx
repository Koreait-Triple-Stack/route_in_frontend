import React, { useState } from "react";
import UserAvatarLink from "../../components/UserAvatarLink";
import { Box, flex } from "@mui/system";
import { Badge, Button, Typography } from "@mui/material";
import { usePrincipalState } from "../../store/usePrincipalState";
import MessageModal from "./MessageModal";

function MessageBubbleComponent({ message }) {
    const { principal } = usePrincipalState();
    const {
        messageId,
        roomId,
        senderId,
        type,
        content,
        createDt,
        profileImg,
        username,
        unreadCnt,
    } = message;
    const isMiddle = !message.senderId;
    const isMe = message.senderId === principal?.userId;
    const event = new Date(createDt);
    const time = event.toLocaleString("ko-KR", {
        hour: "numeric",
        minute: "numeric",
        hour12: true,
    });

    const [contextMenuMes, setContextMenuMes] = useState(null);
    const [selectedMessage, setSelectedMessage] = useState(null);
    const handleContextMenu = (event, message) => {
        event.preventDefault(); // 브라우저 기본 메뉴(복사/인쇄 등)가 안 뜨게 막음!
        setSelectedMessage(message); // 어떤 채팅방을 눌렀는지 저장
        setContextMenuMes(
            contextMenuMes === null
                ? {
                      mouseX: event.clientX,
                      mouseY: event.clientY,
                  }
                : null,
        );
    };

    return (
        <Box
            sx={{
                display: "flex",
                flexDirection: isMe ? "row-reverse" : "row", // 내꺼면 오른쪽, 남이면 왼쪽
                alignItems: "flex-start",
                mb: 2,
                width: "100%",
                height: "100%",
            }}>
            {!isMe && !isMiddle && (
                <UserAvatarLink userId={senderId} src={profileImg} size={48} />
            )}
            {isMiddle ? (
                <Box
                    sx={{
                        width: "100%",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        mb: 1,
                        mt: 1,
                    }}>
                    <Typography
                        sx={{
                            display: "inline-block",
                            bgcolor: "grey.500",
                            color: "#fff",
                            px: 2,
                            py: 0.5,
                            borderRadius: 10,
                            fontSize: "0.75rem",
                        }}>
                        {message.content}
                    </Typography>
                </Box>
            ) : (
                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: isMe ? "flex-end" : "flex-start",
                        ml: 1,
                    }}>
                    {/* 상대방 이름 */}
                    {!isMe && (
                        <Typography
                            variant="caption"
                            sx={{ color: "#555", mb: 0.5, ml: 0.5 }}>
                            {username}
                        </Typography>
                    )}

                    {/* 말풍선과 시간 배치 */}
                    <Box
                        sx={{
                            display: "flex",
                            flexDirection: isMe ? "row-reverse" : "row", // 시간 위치 조정을 위해
                            alignItems: "flex-end", // 말풍선 하단에 시간 정렬
                        }}>
                        {/* 💬 말풍선 */}
                        <Box
                            onContextMenu={(e) => {
                                handleContextMenu(e, message);
                            }}
                            sx={{
                                bgcolor: isMe ? "primary.main" : "#FFFFFF",
                                color: isMe ? "#FFF" : "#000",
                                p: "10px 14px",
                                borderRadius: isMe
                                    ? "15px 0px 15px 15px"
                                    : "0px 15px 15px 15px", // 꼬리 모양 흉내
                                maxWidth: "70vw", // 화면의 70%까지만 차지
                                boxShadow: "0 1px 1px rgba(0,0,0,0.1)",
                                wordBreak: "normal",
                                fontSize: "0.95rem",
                                lineHeight: 1.5,
                                whiteSpace: "pre-wrap",
                            }}>
                            {content}
                        </Box>

                        <Box
                            sx={{
                                display: "flex",
                                flexDirection: "column",
                                justifyContent: "flex-end",
                                alignItems: isMe ? "flex-end" : "flex-start",
                                mx: 0.5,
                                height: "100%",
                            }}>
                            {/* 안읽은 표시 (Badge 대신 Box나 Typography로 직접 구현이 위치 잡기 더 쉽습니다) */}
                            {unreadCnt > 0 && (
                                <Box
                                    sx={{
                                        color: "primary.main",
                                        fontSize: "0.75rem",
                                        fontWeight: "bold",
                                        height: "10px",
                                        borderRadius: "50%",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                    }}>
                                    {unreadCnt}
                                </Box>
                            )}

                            {/* 시간 표시 */}
                            <Typography
                                variant="caption"
                                sx={{
                                    color: "#555",
                                    fontSize: "0.7rem",
                                    minWidth: "max-content",
                                }}>
                                {time}
                            </Typography>
                        </Box>
                    </Box>
                </Box>
            )}

            <MessageModal
                setContextMenuMes={setContextMenuMes}
                contextMenuMes={contextMenuMes}
                selectedMessage={selectedMessage}
                setSelectedMessage={setSelectedMessage}
            />
        </Box>
    );
}

export default MessageBubbleComponent;
