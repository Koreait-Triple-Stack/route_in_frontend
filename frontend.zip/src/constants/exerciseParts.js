export const EXERCISE_PARTS = [
    "가슴",
    "등",
    "하체",
    "어깨",
    "팔",
    "유산소",
    "스트레칭",
];
