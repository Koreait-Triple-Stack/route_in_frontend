import React, { useMemo, useState } from "react";
import { Box, Button, TextField } from "@mui/material";
import { useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { usePrincipalState } from "../../store/usePrincipalState";
import {
  getBoardByBoardIdRequest,
  removeBoardRequest,
  updateBoardRequest,
} from "../../apis/board/boardApi";

function BoardDetailPage() {
  const { boardId } = useParams();
  const boardIdNum = Number(boardId);

  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { principal } = usePrincipalState();
  const userId = principal?.userId;

  const [form, setForm] = useState({
    title: "",
    content: "",
  });

  const onChangeHandler = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // 권한 체크
  const isOwner = useMemo(() => {
    return !!userId && !!boardData?.userId && userId === boardData.userId;
  }, [userId, boardData]);


  // 수정Mutation
  const updateMutation = useMutation({
    mutationKey: ["updateBoard", Number(boardId)],
    mutationFn: updateBoardRequest,
    onSuccess: (response) => {
      if (response.data.status === "success") {
        alert("게시물이 수정 되었습니다.");

        queryClient.invalidateQueries({
          queryKey: ["getBoardByBoardId", Number(boardId)],
        });
        queryClient.invalidateQueries({ queryKey: ["getBoardListInfinite"] });

        const typeLower = (boardData?.type ?? "").toLowerCase();
        navigate(`/board/${typeLower}/${boardId}`);
        return;
      }
      alert(response.data.message);
    },
    onError: (error) => {
      alert(error?.message ?? "수정 실패");
    },
  });

  const editOnClickHandler = () => {
    if (!userId) return alert("로그인이 필요합니다.");
    if (!isOwner) return alert("수정 권환이 없습니다.");
    if (form.title.trim().length === 0 || form.content.trim().length === 0) {
      alert("모든 항목을 입력해주세요.");
      return;
    }

    updateMutation.mutate({
      title: form.title.trim(),
      content: form.content.trim(),
      userId: principal.userId,
      boardId: Number(boardId),
    });
  };

  // 삭제 Mutation
  const removeMutation = useMutation({
    mutationKey: ["removeBoard", Number(boardId)],
    mutationFn: removeBoardRequest,
    onSuccess: (response) => {
      if (response.data.status === "success") {
        alert("게시물이 삭제 되었습니다.");

        queryClient.invalidateQueries({ queryKey: ["getBoardListInfinite"] });
        queryClient.invalidateQueries({
          queryKey: ["getBoardByBoardId", Number(boardId)],
        });

        navigate("/board");
        return;
      }
      alert(response.data.message);
    },
    onError: (error) => {
      alert(error?.message ?? "삭제 실패");
    },
  });

  const removeOnClickHandler = () => {
    if (!window.confirm("정말로 게시물을 삭제하시겠습니까?")) return;

    removeMutation.mutate({
      userId: principal.userId,
      boardId: Number(boardId),
    });
  };
  return (
    <Box>
      <TextField name="title" value={form.title} onChange={onChangeHandler} />
      <TextField
        name="content"
        value={form.content}
        onChange={onChangeHandler}
        multiline
        minRows={5}
      />

      <Button onClick={editOnClickHandler} disabled={updateMutation.isPending}>
        수정
      </Button>
      <Button
        onClick={removeOnClickHandler}
        disabled={removeMutation.isPending}
      >
        삭제
      </Button>
    </Box>
  );
}
export default BoardDetailPage;
